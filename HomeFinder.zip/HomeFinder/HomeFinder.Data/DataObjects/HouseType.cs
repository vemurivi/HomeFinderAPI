﻿namespace HomeFinder.Data.DataObjects
{
    public enum HouseType
    {
       Condominium = 1, 
       TownHouse = 2,
       Apartment = 3,
       IndependentHome = 4
    }
}
