﻿using HomeFinder.Data.DataObjects;

namespace HomeFinder.Data.Repository.Interfaces
{
    public interface IHouseRepo : IGenericRepo<House>
    {
    }
}
