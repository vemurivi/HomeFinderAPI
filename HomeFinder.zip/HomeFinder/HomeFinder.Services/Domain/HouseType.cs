﻿namespace HomeFinder.Services.Domain
{
    public enum HouseType
    {
       Condominium = 1, 
       TownHouse = 2,
       Apartment = 3,
       IndependentHome = 4
    }
}
